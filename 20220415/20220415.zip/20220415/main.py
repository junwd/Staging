from selenium import webdriver
import time
import csv
driver=webdriver.PhantomJS()
driver.get("http://www.jd.com")
product=input("请你输入要搜索的内容:")
id=driver.find_element_by_id("key")
id.send_keys(product)
submit=driver.find_element_by_class_name("button")
submit.click()
time.sleep(3)
# driver.save_screenshot("京东.png")
js="window.scrollTo(0,document.body.scrollHeight)"  #脚本
driver.execute_script(js)
time.sleep(2)
r_list = driver.find_elements_by_xpath('//div[@id="J_goodsList"]//li')
for r in r_list:
    m=r.text.split("\n")
    # print(m)
    with open("ass.csv", 'a', newline="", encoding="utf_8") as f:
        writer = csv.writer(f)
        writer.writerow(r_list)






